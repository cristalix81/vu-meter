Исходный код Audio Visualizer Pro 4.3.0. Для разработки откройте desktop/README_BUILD_RU.md.
Для готовой программы нужен полный ZIP AudioVisualizerPro-Desktop-VU-4.3.0.zip.
